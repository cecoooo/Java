create
    definer = root@localhost procedure ex5(IN idProvider int, IN idRecipient int, IN sumAmount double)
begin
	start transaction;
		select @initialValue := amount from customer_accounts where id = IdProvider;
		update customer_accounts
        set amount = case when
			amount < sumAmount then amount
            else amount - sumAmount end
        where id = idProvider;
        select @changedValue := amount from customer_accounts where id = IdProvider;
        if @initialValue = @changedValue then 
        signal sqlstate '45000' set message_text = 'Not enough money in the discount.';
        end if;
        select @currencyProvider := currency from customer_accounts where id = IdProvider;
        select @currencyRecipient := currency from customer_accounts where id = IdRecipient;
        set @sumToAdd = sumAmount;
        if @currencyProvider not like @currencyRecipient then 
        set @sumToAdd = 0;
        call convert_currency(sumAmount, @currencyProvider, @sumToAdd);
        end if;
        update customer_accounts
        set amount = amount + @sumToAdd
        where id = idRecipient;
	commit;
end;

