create
    definer = root@localhost procedure mess(IN currSum double, IN wantedSum double)
begin
	signal sqlstate '45000' set message_text = 'Not enough money in the discount.';
end;

