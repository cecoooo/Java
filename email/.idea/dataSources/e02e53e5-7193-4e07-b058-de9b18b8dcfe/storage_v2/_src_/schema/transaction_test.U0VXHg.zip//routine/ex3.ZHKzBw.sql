create
    definer = root@localhost procedure ex3(IN student_name varchar(255), IN year int)
BEGIN
    SELECT AVG(fee_amount) AS avg_fees
    FROM fees
    WHERE student_id = (
        SELECT id
        FROM students
        WHERE name = student_name
    ) AND YEAR(date_paid) = year;
END;

