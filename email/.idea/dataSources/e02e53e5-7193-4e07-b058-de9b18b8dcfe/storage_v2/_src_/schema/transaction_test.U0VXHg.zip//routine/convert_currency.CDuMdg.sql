create
    definer = root@localhost procedure convert_currency(IN amount double, IN currency varchar(3), OUT res double)
begin
	if currency = 'BGN' then set res = amount/2;
    elseif currency = 'EUR' then set res = amount*2;
    else select 'Invalid currency.';
    end if;
end;

