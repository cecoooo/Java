create definer = root@localhost view studentbygroups as
select count(`s`.`name`) AS `count(s.name)`
from ((`school_sport_clubs`.`students` `s` join `school_sport_clubs`.`student_sport` `ss`
       on ((`s`.`id` = `ss`.`student_id`))) join `school_sport_clubs`.`sportgroups` `sg`
      on ((`sg`.`id` = `ss`.`sportGroup_id`)))
group by `sg`.`sport_id`;

