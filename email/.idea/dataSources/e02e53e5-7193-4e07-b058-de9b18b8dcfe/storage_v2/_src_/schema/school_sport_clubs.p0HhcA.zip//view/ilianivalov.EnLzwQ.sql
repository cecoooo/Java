create definer = root@localhost view ilianivalov as
select `c`.`name` AS `Coach Name`, `sp`.`name` AS `Sport Name`
from ((((`school_sport_clubs`.`coaches` `c` join `school_sport_clubs`.`sportgroups` `sg`
         on ((`c`.`id` = `sg`.`coach_id`))) join `school_sport_clubs`.`sports` `sp`
        on ((`sg`.`sport_id` = `sp`.`id`))) join `school_sport_clubs`.`student_sport` `ss`
       on ((`ss`.`sportGroup_id` = `sg`.`id`))) join `school_sport_clubs`.`students` `s`
      on ((`s`.`id` = `ss`.`student_id`)))
where (`s`.`name` = 'Илиян Иванов');

