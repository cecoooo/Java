create definer = root@localhost view payments as
select sum(`t`.`paymentAmount`) AS `sumAll`, `t`.`month` AS `month`
from (((((`school_sport_clubs`.`taxespayments` `t` join `school_sport_clubs`.`students` `s`
          on ((`s`.`id` = `t`.`student_id`))) join `school_sport_clubs`.`student_sport` `ss`
         on ((`ss`.`student_id` = `s`.`id`))) join `school_sport_clubs`.`sportgroups` `sg`
        on ((`sg`.`id` = `ss`.`sportGroup_id`))) join `school_sport_clubs`.`coaches` `c`
       on ((`c`.`id` = `sg`.`coach_id`))) join `school_sport_clubs`.`sports` `sp` on ((`sg`.`sport_id` = `sp`.`id`)))
where (`c`.`egn` = '7509041245')
group by `t`.`month`
having (`sumAll` > 700);

