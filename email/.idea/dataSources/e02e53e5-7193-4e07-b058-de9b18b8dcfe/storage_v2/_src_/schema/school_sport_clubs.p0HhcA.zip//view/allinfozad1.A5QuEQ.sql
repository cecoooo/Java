create definer = root@localhost view allinfozad1 as
select `school_sport_clubs`.`coaches`.`name`                AS `name`,
       `school_sport_clubs`.`sportgroups`.`location`        AS `groupInfo`,
       `school_sport_clubs`.`sports`.`name`                 AS `sport`,
       `school_sport_clubs`.`salarypayments`.`year`         AS `year`,
       `school_sport_clubs`.`salarypayments`.`month`        AS `month`,
       `school_sport_clubs`.`salarypayments`.`salaryAmount` AS `salaryAmount`
from (((`school_sport_clubs`.`coaches` join `school_sport_clubs`.`sportgroups`
        on ((`school_sport_clubs`.`coaches`.`id` =
             `school_sport_clubs`.`sportgroups`.`coach_id`))) join `school_sport_clubs`.`sports`
       on ((`school_sport_clubs`.`sports`.`id` =
            `school_sport_clubs`.`sportgroups`.`sport_id`))) join `school_sport_clubs`.`salarypayments`
      on ((`school_sport_clubs`.`salarypayments`.`coach_id` = `school_sport_clubs`.`coaches`.`id`)));

