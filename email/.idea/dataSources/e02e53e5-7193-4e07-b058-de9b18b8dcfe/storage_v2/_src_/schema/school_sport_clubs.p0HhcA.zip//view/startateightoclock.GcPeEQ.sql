create definer = root@localhost view startateightoclock as
select `s`.`name` AS `Student name`, `s`.`class` AS `class`, `sg`.`location` AS `location`, `c`.`name` AS `Coach name`
from (((`school_sport_clubs`.`students` `s` join `school_sport_clubs`.`student_sport` `ss`
        on ((`ss`.`student_id` = `s`.`id`))) join `school_sport_clubs`.`sportgroups` `sg`
       on ((`sg`.`id` = `ss`.`sportGroup_id`))) join `school_sport_clubs`.`coaches` `c`
      on ((`c`.`id` = `sg`.`coach_id`)))
where (`sg`.`hourOfTraining` = '8:00');

