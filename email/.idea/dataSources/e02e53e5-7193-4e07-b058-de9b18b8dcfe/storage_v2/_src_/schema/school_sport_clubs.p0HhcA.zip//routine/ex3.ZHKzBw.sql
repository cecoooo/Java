create
    definer = root@localhost procedure ex3(IN student_name varchar(255), IN year1 int)
BEGIN
    SELECT AVG(paymentAmount) AS avg_fees
    FROM taxespayments
    WHERE student_id = (
        SELECT id
        FROM students
        WHERE name = student_name
    ) AND YEAR(`year`) = year1;
END;

