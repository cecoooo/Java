create definer = root@localhost view volleyballtrainers as
select `school_sport_clubs`.`coaches`.`name` AS `Coach`, `sp`.`name` AS `Sport`
from ((`school_sport_clubs`.`coaches` join `school_sport_clubs`.`sportgroups` `sg`
       on ((`school_sport_clubs`.`coaches`.`id` = `sg`.`coach_id`))) join `school_sport_clubs`.`sports` `sp`
      on ((`sg`.`sport_id` = `sp`.`id`)))
where (`sp`.`name` = 'Volleyball');

