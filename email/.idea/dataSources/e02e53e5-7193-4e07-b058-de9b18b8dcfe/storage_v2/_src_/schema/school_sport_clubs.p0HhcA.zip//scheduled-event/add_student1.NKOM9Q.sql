create definer = root@localhost event add_student1 on schedule
    at '2023-04-16 01:29:04'
    on completion preserve
    disable
    do
    insert into students(id, name, egn, address, phone, class)
    values(10, 'Ivaylo Penchev', '0651135023', 'Pleven, Bulgaria', '0888123443', '10');

