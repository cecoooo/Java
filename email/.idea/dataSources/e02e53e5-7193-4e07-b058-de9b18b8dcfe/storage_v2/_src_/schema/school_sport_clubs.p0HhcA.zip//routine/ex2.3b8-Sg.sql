create
    definer = root@localhost procedure ex2(IN spId int)
begin 
select sp.name as 'sport', s.name as 'students', c.name as 'coaches'
from sports as sp join sportgroups as sg on sp.id = sport_id
join coaches as c on c.id = sg.coach_id
join student_sport as ss on ss.sportgroup_id = sg.id
join students as s on s.id = ss.student_id
where sp.id = spId;
end;

