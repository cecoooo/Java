create definer = root@localhost view trainingfootball as
select `s`.`name` AS `name`, `s`.`class` AS `class`, `s`.`phone` AS `phone`
from (((`school_sport_clubs`.`students` `s` join `school_sport_clubs`.`student_sport` `ss`
        on ((`s`.`id` = `ss`.`student_id`))) join `school_sport_clubs`.`sportgroups` `sg`
       on ((`sg`.`id` = `ss`.`sportGroup_id`))) join `school_sport_clubs`.`sports` `sp`
      on ((`sp`.`id` = `sg`.`sport_id`)))
where (`sp`.`name` = 'Football');

