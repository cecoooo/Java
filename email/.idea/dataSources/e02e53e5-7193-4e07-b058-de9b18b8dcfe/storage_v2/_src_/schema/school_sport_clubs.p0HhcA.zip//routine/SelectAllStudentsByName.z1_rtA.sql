create
    definer = root@localhost procedure SelectAllStudentsByName(INOUT param varchar(30))
begin 
select s.name as 'Student names' from students as s
where s.class = param;
end;

