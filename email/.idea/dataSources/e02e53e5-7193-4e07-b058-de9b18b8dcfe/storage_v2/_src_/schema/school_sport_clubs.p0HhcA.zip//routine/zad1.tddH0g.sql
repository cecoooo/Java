create
    definer = root@localhost procedure zad1(IN coachName varchar(255))
BEGIN
SELECT sp.name as sportName, sg.location, sg.hourOfTraining, sg.dayOfWeek, st.name, st.phone
FROM coaches as co
JOIN sportGroups as sg ON sg.coach_id = co.id
JOIN sports as sp ON sp.id = sg.sport_id
JOIN student_sport as stsp ON stsp.sportGroup_id = sg.id
JOIN students as st ON st.id = stsp.student_id
WHERE co.name = coachName;
END;

