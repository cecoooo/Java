create definer = root@localhost view ilianivanov as
select `school_sport_clubs`.`students`.`name` AS `StudentName`, `sp`.`name` AS `SportName`
from (((`school_sport_clubs`.`students` join `school_sport_clubs`.`student_sport` `ss`
        on ((`school_sport_clubs`.`students`.`id` = `ss`.`student_id`))) join `school_sport_clubs`.`sportgroups` `sg`
       on ((`ss`.`sportGroup_id` = `sg`.`id`))) join `school_sport_clubs`.`sports` `sp` on ((`sg`.`id` = `sp`.`id`)))
where (`school_sport_clubs`.`students`.`name` = 'Iliyan Ivanov');

