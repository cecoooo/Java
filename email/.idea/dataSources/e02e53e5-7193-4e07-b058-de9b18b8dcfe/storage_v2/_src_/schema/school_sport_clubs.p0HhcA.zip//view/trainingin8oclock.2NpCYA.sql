create definer = root@localhost view trainingin8oclock as
select `school_sport_clubs`.`students`.`name`  AS `StudentName`,
       `school_sport_clubs`.`students`.`class` AS `Class`,
       `sg`.`location`                         AS `Location`,
       `c`.`name`                              AS `Coach`
from ((((`school_sport_clubs`.`students` join `school_sport_clubs`.`student_sport` `ss`
         on ((`school_sport_clubs`.`students`.`id` = `ss`.`student_id`))) join `school_sport_clubs`.`sportgroups` `sg`
        on ((`ss`.`sportGroup_id` = `sg`.`id`))) join `school_sport_clubs`.`coaches` `c`
       on ((`sg`.`coach_id` = `c`.`id`))) join `school_sport_clubs`.`sports` `sp` on ((`sg`.`sport_id` = `sp`.`id`)))
where (`sg`.`hourOfTraining` = '8:00');

