create definer = root@localhost trigger rewrite_after_delete
    after delete
    on salarypayments
    for each row
begin
	if not exists(select id from salarypayments_log where id = old.id) then
		insert into salarypayments_log(id, coach_id, month, year, salaryAmount, dateOfPayment)
		values(old.id, old.coach_id, old.month, old.year, old.salaryAmount, old.dateOfPayment);
	end if;
end;

