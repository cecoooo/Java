create definer = root@localhost view ex1 as
select `c`.`name`                         AS `coach`,
       `sp`.`name`                        AS `sport`,
       concat(`sg`.`id`, `sg`.`location`) AS `groupInfo`,
       `p`.`year`                         AS `year`,
       `p`.`month`                        AS `month`,
       `p`.`salaryAmount`                 AS `salaryAmount`
from (((`school_sport_clubs`.`coaches` `c` join `school_sport_clubs`.`sportgroups` `sg`
        on ((`sg`.`coach_id` = `c`.`id`))) join `school_sport_clubs`.`sports` `sp`
       on ((`sp`.`id` = `sg`.`sport_id`))) join `school_sport_clubs`.`salarypayments` `p`
      on ((`c`.`id` = `p`.`coach_id`)));

