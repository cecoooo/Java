create definer = root@localhost view volleyballcoaches as
select `c`.`name` AS `name`
from ((`school_sport_clubs`.`coaches` `c` join `school_sport_clubs`.`sportgroups` `sg`
       on ((`sg`.`coach_id` = `c`.`id`))) join `school_sport_clubs`.`sports` `sp` on ((`sp`.`id` = `sg`.`sport_id`)))
where (`sp`.`name` = 'Volleyball');

