create definer = root@localhost view studentscountbygroup as
select count(`ss`.`student_id`) AS `CountOFStudentsinGroups`
from (`school_sport_clubs`.`students` join `school_sport_clubs`.`student_sport` `ss`
      on ((`school_sport_clubs`.`students`.`id` = `ss`.`student_id`)))
group by `ss`.`sportGroup_id`;

