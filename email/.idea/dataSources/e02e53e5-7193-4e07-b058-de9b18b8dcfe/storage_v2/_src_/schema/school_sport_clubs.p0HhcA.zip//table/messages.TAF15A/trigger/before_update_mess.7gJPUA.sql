create definer = root@localhost trigger before_update_mess
    before update
    on messages
    for each row
begin
	set @errorMess = concat('New content(', new.content, ') must be longer than current content(', old.content, ').');
	if new.content < old.content
    then signal sqlstate '45000' set message_text = @errorMess;
    end if;
end;

