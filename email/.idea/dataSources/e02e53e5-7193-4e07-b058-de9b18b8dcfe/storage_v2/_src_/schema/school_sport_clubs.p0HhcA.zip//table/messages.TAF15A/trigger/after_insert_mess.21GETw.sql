create definer = root@localhost trigger after_insert_mess
    after insert
    on messages
    for each row
begin
	if new.date_hour > concat(current_date, ' 15:00:00') or new.date_hour < concat(current_date, ' 07:00:00')
    then signal sqlstate '45000' set message_text = 'you can add messages every day between 07:00 and 15:00';
    end if;
end;

