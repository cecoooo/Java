create
    definer = root@localhost procedure ex2(IN customerId int, IN plan_id int)
begin
		declare fee double;
        declare isThere bool default false;
		declare finished int;
        declare currCus, currPlan int;
        declare curDebts cursor for select customer_id, plan_id from debtors;
        declare continue handler for not found set finished = 1;
        set finished = 0;
		start transaction;
        
			select monthly_fee into fee from plans where planID = plan_id;
			
			if (select amount from accounts where customer_id = customerId) >= fee then
            update accounts
            set amount = amount - fee
            where customer_id = customerId;
            else
				open curDebts;
				getRecords: loop
					fetch curDebts into currCus, CurrPlan;
                    if finished = 1 then leave getRecords;
                    end if;
                    if currCus = customerId and currPlan = plan_id then set isThere = true;
                    update debtors
                    set debt_amount = debt_amount + fee
                    where currCus = customer_id and currPlan = plan_id;
                    end if;
                end loop getRecords;
                
                if isThere = false then 
                insert into debtors(customer_id, plan_id, debt_amount)
                values(customerId, plan_id, fee);
                end if;
			end if;
		commit;
end;

