create
    definer = root@localhost procedure ex1(IN customerId int, IN sum double, OUT result bit)
begin
		declare curSum double;
        
		start transaction;
		
			select amount into curSum 
			from accounts
			where customer_id = customerId;
			
			if curSum < sum then 
			set result = 0;
			rollback;
            else 
            update accounts
            set amount = amount - sum
            where customer_id = customerId;
            set result = 1;
			end if;
    commit;
end;

