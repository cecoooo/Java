create definer = root@localhost event deliveryTrue on schedule
    at '2023-06-14 22:42:37'
    on completion preserve
    disable
    do
    update orders
set is_filled = true
where order_date = current_timestamp() - interval 3 day;

