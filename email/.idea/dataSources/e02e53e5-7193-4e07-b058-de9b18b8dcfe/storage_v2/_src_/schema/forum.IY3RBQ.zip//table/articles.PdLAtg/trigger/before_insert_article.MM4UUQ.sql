create definer = root@localhost trigger before_insert_article
    before insert
    on articles
    for each row
begin 
    set new.time_of_pub = current_timestamp();
end;

