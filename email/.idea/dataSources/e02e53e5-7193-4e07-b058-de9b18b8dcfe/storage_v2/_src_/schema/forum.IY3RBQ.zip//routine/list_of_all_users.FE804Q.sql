create
    definer = root@localhost procedure list_of_all_users(INOUT u_list varchar(4000))
begin
	declare finish int;
    declare us varchar(50);
    declare cursorUser cursor for select username from users;
    declare continue handler for not found set finish = 1;
    
    open cursorUser;
    getUser: loop
		fetch cursorUser into us;
        if finish = 1 then leave getUser; end if;
        set u_list = concat(us, ';', u_list);
        end loop getUser;
	close cursorUser;
end;

