create
    definer = root@localhost procedure create_error(IN arg varchar(4))
begin
	set @mess = '';
	if(arg = 'name') then
		set @mess = 'Username must be at least 4 symbols long.';
	elseif(arg = 'pass') then
		set @mess = 'Password must be at least 6 symbols long.';
	elseif(arg = 'adm') then
		set @mess = 'User has no admin rights to create articles.';
	end if;
    signal sqlstate '45000' set message_text = @mess;
end;

