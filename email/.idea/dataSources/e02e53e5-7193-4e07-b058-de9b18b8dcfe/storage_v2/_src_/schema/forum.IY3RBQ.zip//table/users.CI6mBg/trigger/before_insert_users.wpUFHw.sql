create definer = root@localhost trigger before_insert_users
    before insert
    on users
    for each row
begin
	if(length(new.username) < 4) then call create_error('name');
    elseif(length(new.pass) < 6) then call create_error('pass');
    end if;
end;

