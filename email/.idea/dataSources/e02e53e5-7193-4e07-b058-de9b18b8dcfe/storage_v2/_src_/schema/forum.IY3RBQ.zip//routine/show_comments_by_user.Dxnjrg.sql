create
    definer = root@localhost procedure show_comments_by_user(IN usname varchar(30), IN pass varchar(30))
begin
	select c.content from comments as c
	join users as u on u.id = c.user_id
    where u.username = usname and u.pass = pass
    order by time_of_pub;
end;

