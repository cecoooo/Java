create definer = root@localhost trigger before_insert_admins_articles
    before insert
    on admins_articles
    for each row
begin
    if((select is_admin from users where id = new.admin_id) = false) then
		call create_error('adm');
	end if;
end;

