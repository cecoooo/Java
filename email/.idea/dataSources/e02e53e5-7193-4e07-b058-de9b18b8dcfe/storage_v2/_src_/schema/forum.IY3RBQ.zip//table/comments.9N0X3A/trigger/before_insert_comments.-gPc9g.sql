create definer = root@localhost trigger before_insert_comments
    before insert
    on comments
    for each row
begin 
    set new.time_of_pub = current_timestamp;
end;

