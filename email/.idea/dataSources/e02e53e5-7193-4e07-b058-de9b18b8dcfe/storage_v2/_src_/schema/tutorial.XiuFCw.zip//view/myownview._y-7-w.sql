create definer = root@localhost view myownview as
select `c`.`CustomerName` AS `CustomerName`, `p`.`ProductName` AS `ProductName`
from `tutorial`.`customers` `c`
         join `tutorial`.`products` `p`;

